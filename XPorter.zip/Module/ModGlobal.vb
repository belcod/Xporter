﻿Imports MySql.Data.MySqlClient

Module ModGlobal
    Public conn As New MySqlConnection
    Public dbhost As String
    Public dbnama As String
    Public dbport As Integer
    Public dbuser As String
    Public dbpassword As String
    Public sstr As String
    Public Sub Getdbsetting()
        Configdb()
        dbhost = My.Settings.S_host
        dbport = My.Settings.S_port
        dbuser = My.Settings.S_user
        dbpassword = My.Settings.S_pass
        dbnama = My.Settings.S_dbname
        sstr = "Server=" & dbhost & ";Port=" & dbport & ";User=" & dbuser & ";Password=" & dbpassword & ";Database=" & dbnama & ";Pooling=True;Min Pool Size=0;Max Pool Size=100;connection Lifetime=0;"
        Statuskoneksi()
    End Sub
    Public Function DBConnected(Optional ByVal Server As String = Nothing,
                          Optional ByVal Port As Integer = 0,
                          Optional ByVal User As String = Nothing,
                          Optional ByVal Password As String = Nothing,
                          Optional ByVal Database As String = Nothing) As Boolean

        conn = New MySqlConnection
        If Server = Nothing And Port = 0 And User = Nothing And Password = Nothing And Database = Nothing Then
            conn.ConnectionString = sstr
        Else
            conn.ConnectionString = "Server=" & Server & ";Port=" & Port & ";User=" & User & ";Password=" & Password & ";Database=" & Database
        End If
        Try
            conn.Open()
            conn.Close()
            Return True
        Catch myerror As MySqlException
            Return False
            MessageBox.Show("Error:" & myerror.Message)
        Finally
            conn.Dispose()
        End Try

    End Function
    Dim kueri As New ClsQuery
    Public Sub Statuskoneksi()
        Try
            If DBConnected(dbhost, dbport, dbuser, dbpassword, dbnama) = True Then
                FormMain.TSProgressBar.Style = ProgressBarStyle.Marquee
                FormMain.TSStatusKoneksi.Text = "Database connected"
                kueri.LoadTabelKeComboBox(FormMain.CmbTabel)
                Exit Sub
            ElseIf DBConnected(dbhost, dbport, dbuser, dbpassword, dbnama) = False Then
                FormMain.TSProgressBar.Style = ProgressBarStyle.Blocks
                FormMain.TSStatusKoneksi.Text = "Database failed"
                kueri.LoadTabelKeComboBox(FormMain.CmbTabel)
            End If
        Catch ex As Exception
            MsgBox("Koneksi Database Tidak Stabil", vbCritical, "Hubungi admin")
            FormMain.TSProgressBar.Style = ProgressBarStyle.Blocks
            FormMain.TSStatusKoneksi.Text = "Database failed"
            kueri.LoadTabelKeComboBox(FormMain.CmbTabel)
        End Try
    End Sub
    Public Sub Configdb()
        FormMain.Txtserver.Text = My.Settings.S_host
        FormMain.TxtPortDb.Text = My.Settings.S_port
        FormMain.Txtuser.Text = My.Settings.S_user
        FormMain.Txtpass.Text = My.Settings.S_pass
        FormMain.Txtdb.Text = My.Settings.S_dbname
    End Sub
End Module
