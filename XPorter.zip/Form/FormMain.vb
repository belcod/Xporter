﻿Imports System.IO
Imports ClosedXML.Excel
Imports MySql.Data.MySqlClient

Public Class FormMain
    Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Txtpass.UseSystemPasswordChar = True
        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Dim kueri As New ClsQuery
    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        Configdb()
        Getdbsetting()
    End Sub

    Private Sub BtnAddDb_Click(sender As Object, e As EventArgs) Handles BtnAddDb.Click
        kueri.InsertDb()
    End Sub

    Private Async Sub BtnExport_Click(sender As Object, e As EventArgs) Handles BtnExport.Click
        If CmbTabel.SelectedIndex = -1 Then
            MessageBox.Show("Pilih tabel tujuan terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim namaTabel As String = CmbTabel.SelectedValue.ToString()

        Using fbd As New FolderBrowserDialog()
            fbd.Description = "Pilih folder untuk menyimpan file Excel"
            fbd.SelectedPath = "C:\Exports"

            If fbd.ShowDialog() = DialogResult.OK Then
                Dim exportPath As String = IO.Path.Combine(fbd.SelectedPath, namaTabel & "_" & Now.ToString("yyyyMMdd_HHmmss") & ".xlsx")

                BtnExport.Enabled = False
                BtnImport.Enabled = False
                Me.UseWaitCursor = True

                Try
                    Await Task.Run(Sub()
                                       ' Query seluruh isi tabel
                                       Dim query As String = $"SELECT * FROM `{namaTabel}`"
                                       Dim dt As DataTable = kueri.GetDataTable(query)
                                       If dt Is Nothing Then
                                           MessageBox.Show("Tidak bisa mengambil data dari tabel.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                           Return
                                       End If

                                       ' Export ke Excel
                                       Dim wb As New ClosedXML.Excel.XLWorkbook()
                                       Dim ws = wb.Worksheets.Add(dt, namaTabel)

                                       With ws.Range(ws.Cell(1, 1), ws.Cell(1, dt.Columns.Count))
                                           .Style.Font.Bold = True
                                           .Style.Fill.BackgroundColor = ClosedXML.Excel.XLColor.Blue
                                           .Style.Alignment.Horizontal = ClosedXML.Excel.XLAlignmentHorizontalValues.Center
                                       End With

                                       ws.Columns().AdjustToContents()
                                       wb.SaveAs(exportPath)
                                   End Sub)

                    MessageBox.Show("Export berhasil ke: " & exportPath, "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch ex As Exception
                    MessageBox.Show("Export gagal: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Finally
                    BtnExport.Enabled = True
                    BtnImport.Enabled = True
                    Me.UseWaitCursor = False
                End Try
            End If
        End Using
    End Sub
    Private Async Sub BtnImport1_Click(sender As Object, e As EventArgs)
        If CmbTabel.SelectedIndex = -1 Then
            MessageBox.Show("Pilih tabel tujuan terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Using ofd As New OpenFileDialog()
            ofd.Filter = "Excel Files|*.xlsx"
            ofd.Title = "Pilih file Excel untuk diimport"

            If ofd.ShowDialog() = DialogResult.OK Then
                BtnImport.Enabled = False
                BtnExport.Enabled = False
                Me.UseWaitCursor = True

                Dim namaTabel As String = CmbTabel.SelectedItem.ToString()

                Try
                    Await Task.Run(Sub()
                                       Dim filePath As String = ofd.FileName
                                       Dim dt As New DataTable()

                                       ' === Baca Excel ===
                                       Try
                                           Using stream = New FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
                                               Using workbook = New ClosedXML.Excel.XLWorkbook(stream)
                                                   Dim worksheet = workbook.Worksheets.First()

                                                   ' Ambil header kolom
                                                   For Each cell In worksheet.Row(1).Cells()
                                                       dt.Columns.Add(cell.Value.ToString().Trim())
                                                   Next

                                                   ' Ambil data dari baris kedua
                                                   For Each row In worksheet.RowsUsed().Skip(1)
                                                       dt.Rows.Add(row.Cells(1, dt.Columns.Count).Select(Function(c) c.Value.ToString()).ToArray())
                                                   Next

                                               End Using

                                           End Using

                                       Catch ioex As IOException
                                           Invoke(Sub()
                                                      MessageBox.Show("File sedang dibuka oleh aplikasi lain. Silakan tutup file Excel terlebih dahulu.", "File Terkunci", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                                  End Sub)
                                           Exit Sub
                                       Catch ex As Exception
                                           Invoke(Sub()
                                                      MessageBox.Show("Gagal membaca file Excel: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                                  End Sub)
                                           Exit Sub
                                       End Try

                                       ' === Masukkan ke DB ===
                                       Dim sukses As Integer = 0
                                       Dim gagal As Integer = 0

                                       Using conn As New MySqlConnection(sstr)
                                           conn.Open()
                                           For Each row As DataRow In dt.Rows
                                               Try
                                                   Dim kolom As String = String.Join(",", dt.Columns.Cast(Of DataColumn).Select(Function(c) $"`{c.ColumnName}`"))
                                                   Dim nilai As String = String.Join(",", dt.Columns.Cast(Of DataColumn).Select(Function(c) $"@{c.ColumnName}"))

                                                   Using cmd As New MySqlCommand($"REPLACE INTO `{namaTabel}` ({kolom}) VALUES ({nilai})", conn)
                                                       For Each col As DataColumn In dt.Columns
                                                           cmd.Parameters.AddWithValue($"@{col.ColumnName}", row(col.ColumnName))
                                                       Next

                                                       sukses += cmd.ExecuteNonQuery()
                                                   End Using
                                               Catch
                                                   gagal += 1
                                               End Try
                                           Next
                                       End Using

                                       ' === Selesai ===
                                       Invoke(Sub()
                                                  MessageBox.Show($"Import selesai!" & vbCrLf &
                                                              $"Berhasil: {sukses} row" & vbCrLf &
                                                              $"Gagal (mungkin duplikat): {gagal} row",
                                                              "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                              End Sub)
                                   End Sub)
                Catch ex As Exception
                    MessageBox.Show("Terjadi kesalahan saat import: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Finally
                    BtnImport.Enabled = True
                    BtnExport.Enabled = True
                    Me.UseWaitCursor = False
                End Try
            End If
        End Using
    End Sub

    Private Async Sub BtnImport_Click(sender As Object, e As EventArgs) Handles BtnImport.Click
        If CmbTabel.SelectedIndex = -1 Then
            MessageBox.Show("Pilih tabel tujuan terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        Dim namaTabel As String = ""
        If TypeOf CmbTabel.SelectedItem Is DataRowView Then
            namaTabel = DirectCast(CmbTabel.SelectedItem, DataRowView)(0).ToString()
        Else
            namaTabel = CmbTabel.SelectedItem.ToString()
        End If

        Using ofd As New OpenFileDialog()
            ofd.Filter = "Excel Files|*.xlsx"
            ofd.Title = "Pilih file Excel untuk diimport"
            If ofd.ShowDialog() = DialogResult.OK Then
                If MessageBox.Show($"Yakin ingin mengimpor data ke tabel '{namaTabel}'?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then
                    Return
                End If
                BtnImport.Enabled = False
                BtnExport.Enabled = False
                Me.UseWaitCursor = True

                Try
                    Await Task.Run(Sub()
                                       Dim dt As New DataTable()
                                       Dim sukses As Integer = 0
                                       Dim gagal As Integer = 0
                                       ' === Baca file Excel ===
                                       Using wb = New ClosedXML.Excel.XLWorkbook(ofd.FileName)
                                           Dim ws = wb.Worksheet(1)
                                           Dim range = ws.RangeUsed()
                                           Dim firstRow = range.FirstRowUsed()
                                           Dim columnNames = firstRow.Cells().Select(Function(c) c.Value.ToString()).ToList()

                                           For Each colName In columnNames
                                               dt.Columns.Add(colName)
                                           Next

                                           For Each row In range.RowsUsed().Skip(1)
                                               Dim dr = dt.NewRow()
                                               For i = 0 To columnNames.Count - 1
                                                   dr(i) = row.Cell(i + 1).Value.ToString()
                                               Next
                                               dt.Rows.Add(dr)
                                           Next
                                       End Using

                                       ' === Insert ke DB ===
                                       Using conn As New MySqlConnection(sstr)
                                           conn.Open()
                                           For Each row As DataRow In dt.Rows
                                               Try
                                                   Dim columns = String.Join(",", dt.Columns.Cast(Of DataColumn)().Select(Function(c) $"`{c.ColumnName}`"))
                                                   Dim values = String.Join(",", dt.Columns.Cast(Of DataColumn)().Select(Function(c) $"@{c.ColumnName}"))
                                                   Dim query = $"REPLACE INTO `{namaTabel}` ({columns}) VALUES ({values})"
                                                   Using cmd As New MySqlCommand(query, conn)
                                                       For Each col As DataColumn In dt.Columns
                                                           cmd.Parameters.AddWithValue($"@{col.ColumnName}", row(col.ColumnName))
                                                       Next
                                                       cmd.ExecuteNonQuery()
                                                       sukses += 1
                                                   End Using
                                               Catch
                                                   gagal += 1
                                               End Try
                                           Next
                                       End Using

                                       ' === Update UI setelah selesai (via Invoke) ===
                                       Me.Invoke(Sub()
                                                     MessageBox.Show($"Import selesai!" & vbCrLf &
                                                              $"Berhasil: {sukses} row" & vbCrLf &
                                                              $"Gagal (mungkin duplikat): {gagal} row",
                                                              "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                                 End Sub)
                                   End Sub)

                Catch ex As Exception
                    MessageBox.Show("Gagal import: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                Finally
                    BtnImport.Enabled = True
                    BtnExport.Enabled = True
                    Me.UseWaitCursor = False
                End Try
            End If
        End Using
    End Sub

End Class
