﻿Imports MySql.Data.MySqlClient

Public Class ClsQuery
    Public Sub InsertDb()
        Try
            With My.Settings
                .S_host = FormMain.Txtserver.Text
                .S_port = FormMain.TxtPortDb.Text
                .S_user = FormMain.Txtuser.Text
                .S_dbname = FormMain.Txtdb.Text
                .S_pass = FormMain.Txtpass.Text

                .Save()
                MsgBox("Save configuration succesfully", vbInformation, "Informasi")

                Getdbsetting()
            End With
        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "Informasi")
        End Try
    End Sub

    Public Sub LoadTabelKeComboBox(cmbTabel As ComboBox)
        Try
            Dim dt As New DataTable
            Dim cmd As New MySqlCommand("SHOW TABLES", conn)
            Dim da As New MySqlDataAdapter(cmd)
            da.Fill(dt)

            If dt.Rows.Count > 0 Then
                cmbTabel.DataSource = dt
                cmbTabel.ValueMember = dt.Columns(0).ColumnName

            Else
                cmbTabel.DataSource = Nothing
            End If

        Catch ex As Exception
            cmbTabel.DataSource = Nothing
        End Try
    End Sub
    Public Function GetDataTable(query As String, Optional param As Dictionary(Of String, Object) = Nothing) As DataTable
        Dim dt As New DataTable
        Try
            Using conn As New MySqlConnection(sstr)
                conn.Open()
                Using cmd As New MySqlCommand(query, conn)
                    ' Kalau ada parameter tambahan
                    If param IsNot Nothing Then
                        For Each p In param
                            cmd.Parameters.AddWithValue(p.Key, p.Value)
                        Next
                    End If

                    Using da As New MySqlDataAdapter(cmd)
                        da.Fill(dt)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error ambil data: " & ex.Message)
            Return Nothing
        End Try
        Return dt
    End Function
    Public Function ImportExcelToDataTable(filePath As String) As DataTable
        Dim dt As New DataTable()
        Try
            Using workbook As New ClosedXML.Excel.XLWorkbook(filePath)
                Dim ws = workbook.Worksheet(1) ' Ambil sheet pertama
                Dim firstRowUsed = ws.FirstRowUsed()
                Dim colCount = ws.Row(1).CellsUsed().Count()

                ' Baca Header dulu
                For col As Integer = 1 To colCount
                    dt.Columns.Add(ws.Cell(1, col).GetValue(Of String))
                Next

                ' Loop data dari baris kedua
                For rowNum As Integer = 2 To ws.LastRowUsed().RowNumber()
                    Dim dr As DataRow = dt.NewRow()
                    For col As Integer = 1 To colCount
                        dr(col - 1) = ws.Cell(rowNum, col).GetValue(Of String)
                    Next
                    dt.Rows.Add(dr)
                Next
            End Using
        Catch ex As Exception
            MessageBox.Show("Gagal import: " & ex.Message)
        End Try
        Return dt
    End Function
End Class
